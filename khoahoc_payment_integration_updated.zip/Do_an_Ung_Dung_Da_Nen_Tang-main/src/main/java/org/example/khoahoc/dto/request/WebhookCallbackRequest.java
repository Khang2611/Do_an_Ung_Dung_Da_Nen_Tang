package org.example.khoahoc.dto.request;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class WebhookCallbackRequest {
    Long transactionId;
    String transactionRef;
    Long orderId;
    Long userId;
    BigDecimal amount;
    String status;
    String timestamp;
    String nonce;
}
