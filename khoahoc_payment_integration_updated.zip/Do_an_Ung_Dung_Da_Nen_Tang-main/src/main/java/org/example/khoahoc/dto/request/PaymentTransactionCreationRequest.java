package org.example.khoahoc.dto.request;

import lombok.*;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PaymentTransactionCreationRequest {
    Long userId;
    Long orderId;
    BigDecimal amount;
    String paymentMethod;
    String transactionRef;
    String ipAddress;
}
