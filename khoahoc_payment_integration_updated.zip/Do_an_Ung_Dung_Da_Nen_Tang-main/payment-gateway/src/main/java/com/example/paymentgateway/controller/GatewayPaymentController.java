package com.example.paymentgateway.controller;

import com.example.paymentgateway.dto.request.InitiatePaymentRequest;
import com.example.paymentgateway.dto.response.InitiatePaymentResponse;
import com.example.paymentgateway.service.GatewayPaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/gateway/payments")
@RequiredArgsConstructor
public class GatewayPaymentController {

    private final GatewayPaymentService gatewayPaymentService;

    @PostMapping("/initiate")
    public ResponseEntity<InitiatePaymentResponse> initiate(
            @RequestHeader(value = "X-Api-Key", required = false) String apiKey,
            @RequestHeader(value = "X-Signature", required = false) String signature,
            @RequestBody InitiatePaymentRequest request) {
        return ResponseEntity.ok(gatewayPaymentService.initiate(request));
    }
}
